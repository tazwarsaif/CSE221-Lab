input_file =  open("input1b.txt","r")
output_file = open("output1b.txt","w")
temp = input_file.readline().split(" ")
l,ten = int(temp[0]),int(temp[1])
lis = [int(i) for i in input_file.readline().split(" ")]
p1,p2 = 0,l-1
flag = False
while p1<p2:
    if lis[p1] + lis[p2] == ten:
        output_file.write(f"{p1+1} {p2+1}")
        flag = True
        break
    if lis[p1] + lis[p2] > ten:
        p2 -=1
    elif lis[p1] + lis[p2] < ten:
        p1 += 2
if flag == False:
    output_file.write(f"IMPOSSIBLE")
input_file.close()
output_file.close()
